import { Time } from "@angular/common";

export interface User{
    username:string;
    date:any;
    showtime:any;
    noofseats:any;
    number:any;
}
export interface product{
   producttitle:string;
   description:string;
   productImage:string;
}
export interface movies{
    moviename:string;
    movieImage:string;
    moviedetails:string;
}
