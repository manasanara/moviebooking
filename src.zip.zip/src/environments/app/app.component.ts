import { Component } from '@angular/core';
import { User } from './models/user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  // encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  // nameofclass:string="angular";
  //  version:number=11;
  //  instructor:string="rajesh";

  //  coursedetails={
  //   duration :"2months",
  //   modeoftraining:"online"
  //  };

  //  imagepath:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSz0_sKkYLKumrXCHiLC1JjHBJft_8sf7B9iDEoDYk&s";
  //  status:boolean=true;
  //    data:any;
  //  senddata(x:any){
  //     this.data=x;
  //  }
  // status:boolean=true;
  // changestatus(){
  //   this.status=!this.status;
  // };
  //arr:number[]=[1,2,3,4,5];
  // arr:string[]=[];
  //  sendd(d:string){
  //   this.arr.push(d);
  //  }
  //  userobj: User = {username:"",dob:"",email:""};
   
  //  adduserdata(){
  //    //let obj=this.userobj;
  //    console.log(this.userobj);

  //    this.userobj= {username:"",dob:"",email:""};
  //  }
}
// interface User{
//   username:string;
//   dob:string;
//   email:string;
// }
